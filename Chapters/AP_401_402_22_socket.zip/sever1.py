import socket

server_soc = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
server_port = 1234
server_soc.bind(('127.0.0.1', server_port))

server_soc.listen()
client_soc, addr = server_soc.accept()

client_soc.sendall(b'Hello from server!')
a = client_soc.recv(1024)
print(a.decode('utf-8'))

client_soc.close()

