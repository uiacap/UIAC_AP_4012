import socket


soc = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
port = 1234

soc.connect(('127.0.0.1', port))


a = soc.recv(1024)
print(a.decode('utf-8'))
soc.sendall(b'salam')
soc.close()
