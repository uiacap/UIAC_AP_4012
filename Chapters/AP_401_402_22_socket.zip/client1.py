import socket

soc = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

soc.connect(("127.0.0.1",8000))
b = soc.recv(1024)
print(b.decode("utf-8"))
soc.sendall(b"Hello from client")

soc.close()