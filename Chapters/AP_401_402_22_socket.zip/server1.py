import socket

soc = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
soc.bind(("127.0.0.1", 8000))
soc.listen()

csoc, addr = soc.accept()
#csoc.sendall(b'Hello from server')
#csoc.sendall('Hello from server'.encode("utf-8"))
csoc.sendall(bytes('Hello from server',"utf-8"))
b = csoc.recv(1024)
print(b.decode('utf-8'))

csoc.close()

