import socket
from threading import Thread

def recving(csoc) :
    while csoc:
        try:        
            b = csoc.recv(1024)
            print(b.decode('utf-8'))
        except socket.error:
            break
        
def sending(csoc) :
    while csoc :
        try:
            msg = input()
            csoc.sendall(msg.encode("utf-8"))
        except socket.error:
            break
        
soc = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
soc.bind(("127.0.0.1", 8000))
soc.listen()


csoc, addr = soc.accept()
csoc.sendall(bytes('Hello from server',"utf-8"))
Thread(target=recving, args=(csoc,)).start()
Thread(target=sending, args=(csoc,)).start()


