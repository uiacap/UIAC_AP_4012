import socket
from threading import Thread

def recving(csoc) :
    while csoc:
        try :
            b = csoc.recv(1024)
            print(b.decode('utf-8'))
        except socket.error:
            break

def sending(csoc) :
    while csoc :
        msg = input()
        if msg != 'exit' :
            csoc.sendall(msg.encode("utf-8"))
        else :
            break
    csoc.close()

soc = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

soc.connect(("127.0.0.1",8000))
b = soc.recv(1024)
print(b.decode("utf-8"))
  
Thread(target=recving, args=(soc,)).start()
Thread(target=sending, args=(soc,)).start()