# برنامه ای بنویسید که دو عدد را از ورودی خوانده و سپس از کاراکتر موجود در ایندکس 
# برابر عدد اول خوانده تا ایندکس برابر عدد دوم خوانده شده از فایل را برگرداند

begin,end = map(int,input().split())
with open('new_code.txt',"r") as f:
    f.seek(begin)
    print(f.read(end-begin+1))




