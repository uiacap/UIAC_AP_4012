
with open('test.txt', 'r') as f:
    st = f.read()


f = open('test.txt', 'w')
try:
    f.write('test')
finally:
    f.close()

