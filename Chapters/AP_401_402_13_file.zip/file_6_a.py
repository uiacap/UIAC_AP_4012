#read a file and print each line inverse
with open('friends.txt','r') as f:
    lines = f.readlines()

with open("ifriends.txt",'w') as f:
    for l in lines :
        l1 = l[::-1]
        l1 = l1.replace("\n","")
        f.write(l1+"\n")


