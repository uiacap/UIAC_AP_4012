# Working with binary files
'''
liles that hold photographs, videos, zip files, executable programs, etc. are called binary files:
they’re not organized into lines, and cannot be opened with a normal text editor.
'''

f = open("friends.zip", "rb")
g = open("thecopy.zip", "wb")

while True:
    buf = f.read(1024)
    if len(buf) == 0:
         break
    g.write(buf)
f.close()
g.close()
