# read a file and remove line with #
#code.txt

with open('code.txt','r') as f:
    codes = f.readlines()

with open('new_code.txt','w') as f:
    for line in codes :
        tline = line.lstrip()
        if tline != "" and tline[0] != "#" :
            f.write(line)



