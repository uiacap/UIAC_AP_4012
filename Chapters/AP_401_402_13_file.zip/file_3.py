
# Turning a file into a list of lines
f = open("friends.txt", "r")
xs = f.readlines()
f.close()

# برنامه ای بنویسید که لیستی از نام دوستان که در فایل قرار دارد را خوانده
# و آنها را مرتب شده در فایل دیگری بنویسد.

xs.sort()
with open('new_friends.txt','w') as fw:
    for i in xs:
        fw.write(i)
