# Reading the whole file at once
# normally use this method of processing files
# if we were not interested in the line structure of the file
f = open("test.txt",'r+')
content = f.read()
print(content)

f.write('test')


words = content.split()
print(f"There are {len(words)} words in the file.")

f.seek(20)
f.write("wrihero")

f.close()
'''
seek(offset[, whence])
offset : This is the position of the read/write pointer within the file
whence : This is optional and defaults to 
0 which means absolute file positioning, 
1 which means seek relative to the current position
2 means seek relative to the file's end.
'''
