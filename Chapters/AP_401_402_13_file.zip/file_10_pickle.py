#pickle is a binary serialization format
import pickle

config_dic = {'remote_hostname': 'google.com', 'remote_port': 80}
list = [1,2,3]

with open('config', 'wb') as config_file:
    pickle.dump(config_dic, config_file)
    pickle.dump(list, config_file)


with open('config', 'rb') as config_file:
    config_dic2 = pickle.load(config_file)
    l = pickle.load(config_file)
    print(type(config_dic2))
    print(type(l))
    # After config_dictionary is read from file
    print(config_dic2)
    print(l)
