
myfile = open("test.txt", "r")


while True:                            # Keep reading forever
    theline = myfile.readline()   # Try to read next line
    if len(theline) == 0:           # If there are no more lines
        break                          #     leave the loop

    # Now process the line we've just read
    print(theline, end="")

myfile.close()




# try to open a file that doesn’t exist, we get an error:
# myfile = open("test1.txt", "r")



