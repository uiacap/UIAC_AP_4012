'''
import tkinter as tk

main_window = tk.Tk()
main_window.title('The first program')


#1 label
tk.Label(main_window, text = 'Hello world!').pack()


# calling mainloop method which is used
# when your application is ready to run
# and it tells the code to keep displaying
main_window.mainloop()
'''
#https://realpython.com/python-gui-tkinter/

import tkinter as tk

#A window is an instance of Tkinter’s Tk class
mainw = tk.Tk()
mainw.title('Hello world!')
mainw.geometry('400x500')
# tells Python to run the Tkinter event loop
# his method listens for events, such as button clicks or keypresses, 
# and blocks any code that comes after it from running until you close the window 
mainw.mainloop()
