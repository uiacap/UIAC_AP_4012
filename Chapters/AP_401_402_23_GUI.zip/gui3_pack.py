import tkinter as tk
# pack geometry manager
"""
pack:
1) Compute a rectangular area called a parcel that’s just tall (or wide) enough to hold the widget 
and fills the remaining width (or height) in the window with blank space.
2) Center the widget in the parcel unless a different location is specified
"""

import tkinter as tk

window = tk.Tk()

"""
In the bellow example each label is places at the top most available position.
"""
'''
lbl1 = tk.Label(width=15, height=10, bg="red")
lbl1.pack()

lbl2 = tk.Label(width=5, height=5, bg="yellow")
lbl2.pack()

lbl3 = tk.Label(width=10, height=15, bg="blue")
lbl3.pack()
'''


'''
#fill keyword argument to specify in which direction the frames should fill
lbl1 = tk.Label(width=15, height=10, bg="red")
lbl1.pack(fill=tk.X)


lbl2 = tk.Label(width=5, height=5, bg="yellow")
lbl2.pack(fill=tk.X)
#lbl1.pack()

lbl3 = tk.Label(width=10, height=15, bg="blue")
#lbl3.pack()
lbl3.pack(fill=tk.X)
'''

#'''
# The side keyword argument of .pack() 
# specifies on which side of the window the widget should be placed. 
# These are the available options: tk.TOP, tk.BOTTOM, tk.LEFT, tk.RIGHT
lbl1 = tk.Label(width=15, height=10, bg="red")
lbl1.pack(side=tk.LEFT)

lbl2 = tk.Label(width=5, height=5, bg="yellow")
lbl2.pack(side=tk.RIGHT)

lbl3 = tk.Label(width=10, height=15, bg="blue")
lbl3.pack(side=tk.TOP)
#'''



window.mainloop()