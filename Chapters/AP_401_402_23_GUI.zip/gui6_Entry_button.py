import tkinter as tk

"""
# The Entry widget is used to accept single-line text strings from a user.
Retrieving text with .get()
Deleting text with .delete()
Inserting text with .insert()
"""

def bot_click():
    print(user_ent.get())
    print(pass_ent.get())
    user_ent.delete(0,tk.END)
    pass_ent.delete(0,tk.END)
    #user_ent.insert(5,"salam")
    user_ent.focus()


mainw = tk.Tk()

user_lbl = tk.Label(text="username:")
user_lbl.grid(row = 0, column = 0, pady = 5)

user_ent = tk.Entry()
user_ent.grid(row= 0, column = 1, padx = 5)

pass_label = tk.Label(text="password:")
pass_label.grid(row = 1, column = 0, pady = 5, padx = 5)


# The Entry widget is used to accept single-line text strings from a user.
pass_ent = tk.Entry(show='*')
pass_ent.grid(row=1, column = 1, padx = 5)

tk.Button(text="login", command = bot_click).grid(row=2, column = 1, padx = 5, sticky=tk.E)

mainw.mainloop()
