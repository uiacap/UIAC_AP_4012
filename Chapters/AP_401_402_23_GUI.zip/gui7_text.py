
"""
Text widgets are used for entering text, just like Entry widgets. 
The difference is that Text widgets may contain multiple lines of text. 
With a Text widget, a user can input a whole paragraph or even several pages of text! 
Just like with Entry widgets, you can perform three main operations with Text widgets:
Retrieve text with .get()
Delete text with .delete()
Insert text with .insert()
"""

import tkinter as tk

def btn_click() :
    # .get requires at least one argument.
    # require the start index and or end index
    # index must contain two pieces of information: 
    # (the line number of the character and the position of a character on that line)
    #print(text_box.get())
    #print(text_box.get("1.0","2.3"))
    #get all text
    print(text_box.get("1.0", tk.END))
    #text_box.delete("1.0", tk.END)
    #text_box.insert("1.0", "Hello")
    #text_box.insert(tk.END, "Put me at the end!")
window = tk.Tk()
text_box = tk.Text()
text_box.pack()
btn1 = tk.Button(text="click me!", command=btn_click)
btn1.pack()
window.mainloop()

