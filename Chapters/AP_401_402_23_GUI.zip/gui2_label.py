import tkinter as tk

root = tk.Tk()
#Create a Label widget with the text "Hello, Tkinter" and assign it to a variable called greeting:
greeting_lbl = tk.Label(text="Hello, Tkinter", bg = "red")
# add the label widget to the window
greeting_lbl.pack()

#show a photo on a label
#img = tk.PhotoImage(file="flower.png")
#tk.Label(image=img).pack()

root.mainloop()
