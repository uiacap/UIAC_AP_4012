import tkinter as tk
# pack geometry manager

"""
.grid() works by splitting a window or Frame into rows and columns. 
You specify the location of a widget by calling .grid() 
and passing the row and column indices to the row and column keyword arguments, respectively. 
Both row and column indices start at 0
"""

import tkinter as tk

window = tk.Tk()

#  To add some space around each frame, you can set the padding of each cell in the grid. 
# Padding is just some blank space that surrounds a widget and visually sets its content apart.

#make grid responsive
#window.columnconfigure(0, weight=1)
#window.rowconfigure([0, 1], weight=2)

for i in range(3):
     #making grid responsive
    #window.columnconfigure(i, weight=1)
    #window.rowconfigure(i, weight=1)

    for j in range(3):       

        frame = tk.Frame(
            master=window,
            relief=tk.RAISED,
            borderwidth=1
        )
        frame.grid(row=i, column=j)
        #frame.grid(row=i, column=j, padx=5, pady=5)
        label = tk.Label(master=frame, text=f"Row {i}\nColumn {j}")
        label.pack()

window.mainloop()