"""
When you create a Tkinter application, 
you must call window.mainloop() to start the event loop. 
During the event loop, your application checks if an event has occurred. 
If so, then it’ll execute some code in response.
The event loop is provided for you with Tkinter, 
so you don’t have to write any code that checks for events yourself. 
However, you do have to write the code that will be executed in response to an event. 
In Tkinter, you write functions called event handlers 
for the events that you use in your application.
"""

"""
To call an event handler whenever an event occurs on a widget, use .bind(). 
The event handler is said to be bound to the event because it’s called every time the event occurs.
.bind() always takes at least two arguments:
An event that’s represented by a string of the form "<event_name>", 
where event_name can be any of Tkinter’s events
An event handler that’s the name of the function to be called whenever the event occurs.
You can bind an event handler to any widget in your application
"""

import tkinter as tk

window = tk.Tk()

def handle_click(event):
    print("The button was clicked!")

def handle_keypress(event):
    """Print the character associated to the key pressed"""
    print(event.char)

# Bind keypress event to handle_keypress()
window.bind("<Key>", handle_keypress)

#btn = tk.Button(text="Click me!")
#btn.bind("<Button-3>", handle_click)
#btn.pack()

window.mainloop()