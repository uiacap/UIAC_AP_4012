import tkinter as tk
# pack geometry manager

"""
.grid() works by splitting a window or Frame into rows and columns. 
You specify the location of a widget by calling .grid() 
and passing the row and column indices to the row and column keyword arguments, respectively. 
Both row and column indices start at 0
"""

import tkinter as tk

window = tk.Tk()


lbl1 = tk.Label(width=15, height=10, bg="red")
lbl1.grid(row=0,column=1)

lbl2 = tk.Label(width=5, height=5, bg="yellow")
lbl2.grid(row=3, column=0)

#lbl3 = tk.Label(width=10, height=15, bg="blue")
#lbl3.grid

window.mainloop()